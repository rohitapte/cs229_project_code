import tensorflow as tf
import os
import pandas as pd
import pickle
import numpy as np
import random
from sklearn.model_selection import train_test_split
from tensorflow.python.ops import variable_scope as vs
from tensorflow.python.ops import embedding_ops

EMBED_TYPE='fasttext'
training_data = pd.read_csv("C:\\Users\\tihor\\Documents\\kaggle\\quora\\train.csv")
labels=np.array(list(training_data['is_duplicate']))
v_tr_q1, v_tr_q2 = pickle.load(open("vectorized_train"+EMBED_TYPE, "rb"))
v_ts_q1, v_ts_q2 = pickle.load(open("vectorized_test"+EMBED_TYPE, "rb"))
voc, rev_voc = pickle.load(open("voc_rvoc"+EMBED_TYPE, "rb"))
embs_m = pickle.load(open("embedding_matrix"+EMBED_TYPE, "rb"))

idx = list(range(len(v_tr_q1)))
random.shuffle(idx)
train_idx, val_idx = train_test_split(idx, train_size=0.9)
train_X_q1=v_tr_q1[train_idx]
train_X_q2=v_tr_q2[train_idx]
train_Y=labels[train_idx]
print(train_Y.sum())

val_X_q1=v_tr_q1[val_idx]
val_X_q2=v_tr_q2[val_idx]
val_Y=labels[val_idx]

tf.app.flags.DEFINE_integer("gpu", 1, "Which GPU to use, if you have multiple.")
tf.app.flags.DEFINE_integer("num_epochs",20, "Number of epochs to train.")
tf.app.flags.DEFINE_integer("number_of_words_in_question",30,"The maximum words in each question")
tf.app.flags.DEFINE_integer("hidden_size",600,"Size of the hidden states")
tf.app.flags.DEFINE_float("learning_rate",0.001,"Learning rate.")
tf.app.flags.DEFINE_integer("batch_size",1000,"Batch size to use")
tf.app.flags.DEFINE_float("dropout",0.5,"Fraction of units randomly dropped on non-recurrent connections.")

FLAGS = tf.app.flags.FLAGS
os.environ["CUDA_VISIBLE_DEVICES"] = str(FLAGS.gpu)

#define the model
with tf.variable_scope("QuoraBiRNNModel",initializer=tf.contrib.layers.variance_scaling_initializer(factor=1.0, uniform=True)):
    # placeholders
    q1_ids=tf.placeholder(tf.int32,shape=[None,FLAGS.number_of_words_in_question])
    q1_mask=tf.placeholder(tf.int32,shape=[None,FLAGS.number_of_words_in_question])
    q2_ids=tf.placeholder(tf.int32, shape=[None,FLAGS.number_of_words_in_question])
    q2_mask = tf.placeholder(tf.int32, shape=[None, FLAGS.number_of_words_in_question])
    labels=tf.placeholder(tf.float32,shape=[None,1])
    keep_prob = tf.placeholder_with_default(1.0, shape=())
    is_training=tf.placeholder_with_default(False,shape=())

    #embeddings
    with vs.variable_scope("embeddings"):
        embedding_matrix = tf.constant(embs_m, dtype=tf.float32, name="emb_matrix")
        q1_embs=embedding_ops.embedding_lookup(embedding_matrix,q1_ids)  # shape (batch_size, context_len, embedding_size)
        q2_embs=embedding_ops.embedding_lookup(embedding_matrix,q2_ids)  # shape (batch_size, context_len, embedding_size)

    #build graph
    rnn_cell_fw = tf.contrib.rnn.LSTMCell(FLAGS.hidden_size)
    rnn_cell_fw = tf.contrib.rnn.DropoutWrapper(rnn_cell_fw, input_keep_prob=keep_prob)
    rnn_cell_bw = tf.contrib.rnn.LSTMCell(FLAGS.hidden_size)
    rnn_cell_bw = tf.contrib.rnn.DropoutWrapper(rnn_cell_bw, input_keep_prob=keep_prob)
    with vs.variable_scope("BiRNNLayer"):
        q1_len= tf.reduce_sum(q1_mask, reduction_indices=1)
        q2_len = tf.reduce_sum(q2_mask, reduction_indices=1)
        (fw_out_q1,bw_out_q1),(fw_final_state_q1,bw_final_state_q1)=tf.nn.bidirectional_dynamic_rnn(rnn_cell_fw,rnn_cell_bw,q1_embs,q1_len,dtype=tf.float32)
        (fw_out_q2,bw_out_q2),(fw_final_state_q2,bw_final_state_q2)=tf.nn.bidirectional_dynamic_rnn(rnn_cell_fw,rnn_cell_bw,q2_embs,q2_len,dtype=tf.float32)

        fw_out_last_q1=fw_final_state_q1.h
        bw_out_last_q1=bw_final_state_q1.h
    out_q1=tf.concat([fw_out_q1,bw_out_q1],2)
    out_last_q1=tf.concat([fw_out_last_q1,bw_out_last_q1],1)
    out_q1=tf.nn.dropout(out_q1,keep_prob)
    out_last_q1=tf.nn.dropout(out_last_q1, keep_prob)
    fw_out_last_q2 = fw_final_state_q2.h
    bw_out_last_q2 = bw_final_state_q2.h
    out_q2 = tf.concat([fw_out_q2, bw_out_q2], 2)
    out_last_q2 = tf.concat([fw_out_last_q2, bw_out_last_q2], 1)
    out_q2 = tf.nn.dropout(out_q2, keep_prob)
    out_last_q2 = tf.nn.dropout(out_last_q2, keep_prob)
    q1_q2_prod = out_last_q1 * out_last_q2
    q1_q2_diff = out_last_q1 - out_last_q2
    blended_reps = tf.concat([q1_q2_prod, q1_q2_diff], axis=1)
    blended_reps_normalized=tf.layers.batch_normalization(blended_reps,training=is_training,axis=1)
    blended_reps_normalized=tf.nn.dropout(blended_reps_normalized,keep_prob)
    DENSE_UNITS = 600
    with tf.variable_scope('full_layer1') as scope:
        full_weight1 = tf.get_variable(name='full_layer1_weight', shape=[4 * FLAGS.hidden_size, DENSE_UNITS],dtype=tf.float32, initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_bias1 = tf.get_variable(name='full_layer_bias1', shape=[DENSE_UNITS], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        full_output1 = tf.nn.relu(tf.matmul(blended_reps_normalized, full_weight1) + full_bias1)
        full_output1=tf.nn.dropout(full_output1 ,keep_prob)
        full_weight2 = tf.get_variable(name='full_layer2_weight',shape=[DENSE_UNITS, 1],dtype=tf.float32, initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_bias2 = tf.get_variable(name='full_layer_bias2', shape=[1], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        final_output = tf.matmul(full_output1, full_weight2) + full_bias2
    logits = tf.identity(final_output, name="logits")
    final_output = final_output
    logits = logits
    with vs.variable_scope('loss_var'):
        loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=logits, labels=labels))
        optimizer = tf.train.AdamOptimizer(learning_rate=FLAGS.learning_rate)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            train_op = optimizer.minimize(loss)
        predicted = tf.nn.sigmoid(final_output)
        correct_prediction = tf.equal(tf.round(predicted), labels, name='correct_prediction')
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32), name='accuracy')
        tf.summary.scalar('cost', loss)

sess=tf.Session()
init=tf.global_variables_initializer()
sess.run(init)
idx=list(range(train_X_q1.shape[0]))
for i in range(FLAGS.num_epochs):
    print("Train epoch..."+str(i))
    random.shuffle(idx)
    train_X_q1=train_X_q1[idx]
    train_X_q2=train_X_q2[idx]
    train_Y=train_Y[idx]
    num_batches = int(train_X_q1.shape[0]) // FLAGS.batch_size
    if FLAGS.batch_size * num_batches < train_X_q1.shape[0]: num_batches += 1
    loss_per_batch, batch_lengths = [], []
    accuracy_per_batch = []
    for i in range(num_batches):
        q1_subset=train_X_q1[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        q2_subset=train_X_q2[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        q1_mask_subset = (q1_subset != 0).astype(np.int32)
        q2_mask_subset = (q2_subset != 0).astype(np.int32)
        label_subset=train_Y[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        label_subset=np.reshape(label_subset,(label_subset.shape[0],1))
        train_data_dict={
            q1_ids: q1_subset,
            q1_mask: q1_mask_subset,
            q2_ids: q2_subset,
            q2_mask: q2_mask_subset,
            labels:label_subset,
            keep_prob:(1.0 - FLAGS.dropout),
            is_training:True
        }
        loss_local, _, acc = sess.run([loss, train_op, accuracy], feed_dict=train_data_dict)
        curr_batch_size = train_X_q1.shape[0]
        loss_per_batch.append(loss_local * curr_batch_size)
        accuracy_per_batch.append(acc * curr_batch_size)
        batch_lengths.append(curr_batch_size)
    total_num_examples = sum(batch_lengths)
    train_loss = sum(loss_per_batch) / float(total_num_examples)
    train_accuracy = sum(accuracy_per_batch) / float(total_num_examples)
    print("Total examples in training batch "+str(total_num_examples))
    print("Train Loss "+str(train_loss))
    print("Train accuracy "+str(train_accuracy))
    num_batches = int(val_X_q1.shape[0]) // FLAGS.batch_size
    if FLAGS.batch_size * num_batches < val_X_q1.shape[0]: num_batches += 1
    loss_per_batch, batch_lengths = [], []
    accuracy_per_batch = []
    for i in range(num_batches):
        q1_subset = val_X_q1[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        q2_subset = val_X_q2[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        q1_mask_subset = (q1_subset != 0).astype(np.int32)
        q2_mask_subset = (q2_subset != 0).astype(np.int32)
        label_subset = val_Y[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        label_subset = np.reshape(label_subset, (label_subset.shape[0], 1))
        val_data_dict = {
            q1_ids: q1_subset,
            q1_mask: q1_mask_subset,
            q2_ids: q2_subset,
            q2_mask: q2_mask_subset,
            labels: label_subset,
            keep_prob: 1.0,
            is_training: False
        }
        loss_local, acc, pred = sess.run([loss, accuracy, predicted], feed_dict=val_data_dict)
        curr_batch_size = q1_subset.shape[0]
        loss_per_batch.append(loss_local * curr_batch_size)
        accuracy_per_batch.append(acc * curr_batch_size)
        batch_lengths.append(curr_batch_size)
    total_num_examples = sum(batch_lengths)
    dev_loss = sum(loss_per_batch) / float(total_num_examples)
    dev_accuracy = sum(accuracy_per_batch) / float(total_num_examples)
    print("Total examples in val batch " + str(total_num_examples))
    print("Val Loss " + str(dev_loss))
    print("Val accuracy " + str(dev_accuracy))

train_predictions=[]
val_predictions=[]
num_batches = int(train_X_q1.shape[0]) // FLAGS.batch_size
if FLAGS.batch_size * num_batches < train_X_q1.shape[0]: num_batches += 1
for i in range(num_batches):
    q1_subset=train_X_q1[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
    q2_subset=train_X_q2[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
    q1_mask_subset = (q1_subset != 0).astype(np.int32)
    q2_mask_subset = (q2_subset != 0).astype(np.int32)
    label_subset=train_Y[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
    label_subset=np.reshape(label_subset,(label_subset.shape[0],1))
    train_data_dict={
        q1_ids: q1_subset,
        q1_mask: q1_mask_subset,
        q2_ids: q2_subset,
        q2_mask: q2_mask_subset,
        labels:label_subset,
        keep_prob:(1.0 - FLAGS.dropout),
        is_training:True
    }
    train_output = sess.run(predicted, feed_dict=train_data_dict)
    train_predictions.extend(train_output.tolist())
num_batches = int(val_X_q1.shape[0]) // FLAGS.batch_size
if FLAGS.batch_size * num_batches < val_X_q1.shape[0]: num_batches += 1
for i in range(num_batches):
    q1_subset = val_X_q1[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
    q2_subset = val_X_q2[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
    q1_mask_subset = (q1_subset != 0).astype(np.int32)
    q2_mask_subset = (q2_subset != 0).astype(np.int32)
    label_subset = val_Y[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
    label_subset = np.reshape(label_subset, (label_subset.shape[0], 1))
    val_data_dict = {
        q1_ids: q1_subset,
        q1_mask: q1_mask_subset,
        q2_ids: q2_subset,
        q2_mask: q2_mask_subset,
        labels: label_subset,
        keep_prob: 1.0,
        is_training: False
    }
    val_output = sess.run(predicted, feed_dict=val_data_dict)
    val_predictions.extend(val_output .tolist())
val_predictions_new = []
for item in val_predictions:
    val_predictions_new.append(item[0])
pickle.dump([val_X_q1, val_X_q2,val_Y,val_predictions], open("val_predictions"+EMBED_TYPE, "wb"))
