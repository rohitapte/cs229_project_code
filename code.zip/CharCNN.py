import tensorflow as tf
import os
import pandas as pd
import pickle
import numpy as np
import random
import nltk
from sklearn.model_selection import train_test_split
from tensorflow.python.ops import variable_scope as vs
from tensorflow.python.ops import embedding_ops
from deep_learning_models.word_and_character_vectors import get_char,UNK_ID,PAD_ID
ML_DATA_FILES="c:\\Users\\tihor\\Documents\\ml_data_files\\"
CHAR_DIMENSION=16
emb_matrix, char2id, id2char=get_char(ML_DATA_FILES,CHAR_DIMENSION=CHAR_DIMENSION)
training_data = pd.read_csv("c:\\Users\\tihor\\Documents\\kaggle\\quora\\train.csv")
labels=np.array(list(training_data['is_duplicate']))

CHAR_DIMENSION=16
NUM_WORDS=30
MAX_LEN=20

def char_ids_to_vectors(char_ids,emb_matrix):
    final_list=[]
    for item1 in char_ids:
        first_list=[]
        for item2 in item1:
            first_list.append(emb_matrix[item2].tolist())
        final_list.append(first_list)
    #final_list=np.array(final_list)
    return final_list

def tokens_to_char_ids(tokens,char2id,emb_matrix,num_words=NUM_WORDS,max_length=MAX_LEN):
    """
    convert tokenized sentence into char indices
    any char not present gets converted to unknown
    """
    char_ids=[]
    for w in tokens:
        char_word_ids=[]
        for c in w[:max_length]:
            char_word_ids.append(char2id.get(c,UNK_ID))
        if len(char_word_ids)<max_length:
            char_word_ids.extend([PAD_ID for i in range(max_length-len(char_word_ids))])
        char_ids.append(char_word_ids)
    if len(char_ids)<num_words:
        for i in range(num_words-len(char_ids)):
            char_ids.append([PAD_ID for i in range(max_length)])
    return char_ids_to_vectors(char_ids,emb_matrix)

def process(text,char2id,emb_matrix):
    """
    lowercase, tokenize, filter
    """
    text = str(text).lower()
    words = nltk.word_tokenize(text)
    words=words[:30]
    char_ids=tokens_to_char_ids(words,char2id,emb_matrix)
    return char_ids



training, val= train_test_split(training_data, train_size=0.9)
print(training.shape)
print(val.shape)
print(training['is_duplicate'].sum())
print(val['is_duplicate'].sum())

def truncated_normal_var(name, shape, dtype):
  return(tf.get_variable(name=name, shape=shape, dtype=dtype, initializer=tf.truncated_normal_initializer(stddev=0.05)))
def zero_var(name, shape, dtype):
  return(tf.get_variable(name=name, shape=shape, dtype=dtype, initializer=tf.constant_initializer(0.0)))


tf.app.flags.DEFINE_integer("gpu", 1, "Which GPU to use, if you have multiple.")
tf.app.flags.DEFINE_integer("num_epochs",20, "Number of epochs to train.")
tf.app.flags.DEFINE_integer("number_of_words_in_question",30,"The maximum words in each question")
tf.app.flags.DEFINE_integer("number_of_letters",20,"The maximum letters in each word")
tf.app.flags.DEFINE_integer("hidden_size",200,"Size of the hidden states")
tf.app.flags.DEFINE_float("learning_rate",0.001,"Learning rate.")
tf.app.flags.DEFINE_integer("embed_size",CHAR_DIMENSION,"Batch size to use")
tf.app.flags.DEFINE_integer("CONV_SHAPE",128,"Batch size to use")
tf.app.flags.DEFINE_integer("batch_size",1000,"Batch size to use")
tf.app.flags.DEFINE_float("dropout",0.5,"Fraction of units randomly dropped on non-recurrent connections.")

FLAGS = tf.app.flags.FLAGS
os.environ["CUDA_VISIBLE_DEVICES"] = str(FLAGS.gpu)

#define the model
with tf.variable_scope("QuoraBiRNNModel",initializer=tf.contrib.layers.variance_scaling_initializer(factor=1.0, uniform=True)):
    # placeholders
    q1_vectors=tf.placeholder(tf.float32,shape=[None,FLAGS.number_of_words_in_question,FLAGS.number_of_letters,FLAGS.embed_size])
    q2_vectors=tf.placeholder(tf.float32, shape=[None,FLAGS.number_of_words_in_question,FLAGS.number_of_letters,FLAGS.embed_size])
    labels=tf.placeholder(tf.float32,shape=[None,1])
    keep_prob = tf.placeholder_with_default(1.0, shape=())
    is_training=tf.placeholder_with_default(False,shape=())

    #embeddings
    #with vs.variable_scope("embeddings"):
    #    embedding_matrix = tf.constant(emb_matrix, dtype=tf.float32, name="emb_matrix")
    #    q1_embs=embedding_ops.embedding_lookup(embedding_matrix,q1_ids)  # shape (batch_size, context_len, embedding_size)
    #    q2_embs=embedding_ops.embedding_lookup(embedding_matrix,q2_ids)  # shape (batch_size, context_len, embedding_size)
    #q1_embs_resized=tf.reshape(q1_embs,[-1,FLAGS.number_of_words_in_question,FLAGS.number_of_letters,FLAGS.embed_size])
    #q2_embs_resized=tf.reshape(q2_embs,[-1, FLAGS.number_of_words_in_question, FLAGS.number_of_letters, FLAGS.embed_size])

    #build graph
    with tf.variable_scope('context_conv1') as scope:
        context_conv1_filter = truncated_normal_var(name='context_conv1_filter',shape=[1, 3, FLAGS.embed_size, FLAGS.CONV_SHAPE], dtype=tf.float32)
        strides = [1, 1, 1, 1]
        context_conv1 = tf.nn.conv2d(q1_vectors, context_conv1_filter, strides, padding='SAME')
        context_conv1_bias = zero_var(name='context_conv1_bias', shape=[FLAGS.CONV_SHAPE], dtype=tf.float32)
        context_conv1_add_bias = tf.nn.bias_add(context_conv1, context_conv1_bias)
        context_relu_conv1 = tf.nn.relu(context_conv1_add_bias)
    pool_size = [1, 1, 2, 1]
    context_pool1 = tf.nn.max_pool(context_relu_conv1, ksize=pool_size, strides=pool_size, padding='SAME',
                                   name='context_pool_layer1')

    with tf.variable_scope('context_conv2') as scope:
        context_conv2_filter = truncated_normal_var(name='context_conv2_filter',
                                                    shape=[1, 3, FLAGS.CONV_SHAPE, FLAGS.CONV_SHAPE],
                                                    dtype=tf.float32)
        strides = [1, 1, 1, 1]
        context_conv2 = tf.nn.conv2d(context_pool1, context_conv2_filter, strides, padding='SAME')
        context_conv2_bias = zero_var(name='context_conv2_bias', shape=[FLAGS.CONV_SHAPE], dtype=tf.float32)
        context_conv2_add_bias = tf.nn.bias_add(context_conv2, context_conv2_bias)
        context_relu_conv2 = tf.nn.relu(context_conv2_add_bias)

    pool_size = [1, 1, 3, 1]
    context_pool2 = tf.nn.max_pool(context_relu_conv2, ksize=pool_size, strides=pool_size, padding='SAME',
                                   name='context_pool_layer2')

    with tf.variable_scope('context_conv3') as scope:
        context_conv3_filter = truncated_normal_var(name='context_conv3_filter',
                                                    shape=[1, 3, FLAGS.CONV_SHAPE, FLAGS.CONV_SHAPE],
                                                    dtype=tf.float32)
        strides = [1, 1, 1, 1]
        context_conv3 = tf.nn.conv2d(context_pool2, context_conv3_filter, strides, padding='SAME')
        context_conv3_bias = zero_var(name='context_conv3_bias', shape=[FLAGS.CONV_SHAPE], dtype=tf.float32)
        context_conv3_add_bias = tf.nn.bias_add(context_conv3, context_conv3_bias)
        context_relu_conv3 = tf.nn.relu(context_conv3_add_bias)
    pool_size = [1, 1, 4, 1]
    context_pool3 = tf.nn.max_pool(context_relu_conv3, ksize=pool_size, strides=pool_size, padding='SAME',
                                   name='context_pool_layer3')
    #context_flattened_layer = tf.reshape(context_pool3,[-1, FLAGS.number_of_words_in_question, 2 * FLAGS.CONV_SHAPE])  # batch,300,192
    context_flattened_layer = tf.reshape(context_pool3,[-1, FLAGS.number_of_words_in_question* 2 * FLAGS.CONV_SHAPE])  # batch,300,192

    with tf.variable_scope('qn_conv1') as scope:
        qn_conv1_filter = truncated_normal_var(name='qn_conv1_filter', shape=[1, 3, FLAGS.embed_size, FLAGS.CONV_SHAPE],
                                               dtype=tf.float32)
        strides = [1, 1, 1, 1]
        qn_conv1 = tf.nn.conv2d(q2_vectors, qn_conv1_filter, strides, padding='SAME')
        qn_conv1_bias = zero_var(name='qn_conv1_bias', shape=[FLAGS.CONV_SHAPE], dtype=tf.float32)
        qn_conv1_add_bias = tf.nn.bias_add(qn_conv1, qn_conv1_bias)
        qn_relu_conv1 = tf.nn.relu(qn_conv1_add_bias)
    pool_size = [1, 1, 2, 1]
    qn_pool1 = tf.nn.max_pool(qn_relu_conv1, ksize=pool_size, strides=pool_size, padding='SAME', name='qn_pool_layer1')

    with tf.variable_scope('qn_conv2') as scope:
        qn_conv2_filter = truncated_normal_var(name='qn_conv2_filter',
                                               shape=[1, 3, FLAGS.CONV_SHAPE, FLAGS.CONV_SHAPE],
                                               dtype=tf.float32)
        strides = [1, 1, 1, 1]
        qn_conv2 = tf.nn.conv2d(qn_pool1, qn_conv2_filter, strides, padding='SAME')
        qn_conv2_bias = zero_var(name='qn_conv2_bias', shape=[FLAGS.CONV_SHAPE], dtype=tf.float32)
        qn_conv2_add_bias = tf.nn.bias_add(qn_conv2, qn_conv2_bias)
        qn_relu_conv2 = tf.nn.relu(qn_conv2_add_bias)

    pool_size = [1, 1, 3, 1]
    qn_pool2 = tf.nn.max_pool(qn_relu_conv2, ksize=pool_size, strides=pool_size, padding='SAME', name='qn_pool_layer2')

    with tf.variable_scope('qn_conv3') as scope:
        qn_conv3_filter = truncated_normal_var(name='qn_conv3_filter',
                                               shape=[1, 3, FLAGS.CONV_SHAPE, FLAGS.CONV_SHAPE],
                                               dtype=tf.float32)
        strides = [1, 1, 1, 1]
        qn_conv3 = tf.nn.conv2d(qn_pool2, qn_conv3_filter, strides, padding='SAME')
        qn_conv3_bias = zero_var(name='qn_conv3_bias', shape=[FLAGS.CONV_SHAPE], dtype=tf.float32)
        qn_conv3_add_bias = tf.nn.bias_add(qn_conv3, qn_conv3_bias)
        qn_relu_conv3 = tf.nn.relu(qn_conv3_add_bias)
    pool_size = [1, 1, 3, 1]
    qn_pool3 = tf.nn.max_pool(qn_relu_conv3, ksize=pool_size, strides=pool_size, padding='SAME', name='qn_pool_layer3')
    #qn_flattened_layer = tf.reshape(qn_pool3, [-1, FLAGS.number_of_words_in_question, 2 * FLAGS.CONV_SHAPE])  # batch,30,128
    qn_flattened_layer = tf.reshape(qn_pool3,[-1, FLAGS.number_of_words_in_question*2 * FLAGS.CONV_SHAPE])  # batch,30,128

    q1_q2_prod = context_flattened_layer * qn_flattened_layer
    q1_q2_diff = context_flattened_layer - qn_flattened_layer
    blended_reps = tf.concat([q1_q2_prod, q1_q2_diff], axis=1)
    blended_reps_normalized = tf.layers.batch_normalization(blended_reps, training=is_training, axis=1)
    blended_reps_normalized = tf.nn.dropout(blended_reps_normalized, keep_prob)
    with tf.variable_scope('full_layer1') as scope:
        full_weight1 = tf.get_variable(name='full_layer1_weight', shape=[FLAGS.number_of_words_in_question*2 * FLAGS.CONV_SHAPE*2, 4096],dtype=tf.float32, initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_bias1 = tf.get_variable(name='full_layer_bias1', shape=[4096], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        full_output1 = tf.nn.relu(tf.matmul(blended_reps, full_weight1) + full_bias1)
        full_output1=tf.nn.dropout(full_output1,keep_prob)

        full_weight2 = tf.get_variable(name='full_layer2_weight',shape=[4096, 1024],dtype=tf.float32, initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_bias2 = tf.get_variable(name='full_layer_bias2', shape=[1024], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        full_output2 = tf.nn.relu(tf.matmul(full_output1, full_weight2) + full_bias2)
        full_output2 = tf.nn.dropout(full_output2, keep_prob)


        full_weight3 = tf.get_variable(name='full_layer3_weight', shape=[1024, 256], dtype=tf.float32,initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_bias3 = tf.get_variable(name='full_layer_bias3', shape=[256], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        full_output3 = tf.nn.relu(tf.matmul(full_output2, full_weight3) + full_bias3)
        full_output3 = tf.nn.dropout(full_output3, keep_prob)

        full_weight4 = tf.get_variable(name='full_layer4_weight', shape=[256,64], dtype=tf.float32,initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_bias4 = tf.get_variable(name='full_layer_bias4', shape=[64], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        full_output4 = tf.nn.relu(tf.matmul(full_output3, full_weight4) + full_bias4)
        full_output4= tf.nn.dropout(full_output4, keep_prob)

        full_weightfinal = tf.get_variable(name='full_layerfinal_weight', shape=[64, 1], dtype=tf.float32,initializer=tf.truncated_normal_initializer(stddev=0.05))
        full_biasfinal = tf.get_variable(name='full_layer_biasfinal', shape=[1], dtype=tf.float32,initializer=tf.constant_initializer(0.0))
        final_output = tf.matmul(full_output4, full_weightfinal) + full_biasfinal

    logits = tf.identity(final_output, name="logits")
    final_output = final_output
    logits = logits
    with vs.variable_scope('loss_var'):
        loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=logits, labels=labels))
        optimizer = tf.train.AdamOptimizer(learning_rate=FLAGS.learning_rate)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            train_op = optimizer.minimize(loss)
        predicted = tf.nn.sigmoid(final_output)
        correct_prediction = tf.equal(tf.round(predicted), labels, name='correct_prediction')
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32), name='accuracy')
        tf.summary.scalar('cost', loss)

from sklearn.utils import shuffle

sess=tf.Session()
init=tf.global_variables_initializer()
sess.run(init)
for i in range(FLAGS.num_epochs):
    print("Train epoch..."+str(i))
    training=shuffle(training)
    num_batches = int(training.shape[0]) // FLAGS.batch_size
    if FLAGS.batch_size * num_batches < training.shape[0]: num_batches += 1
    loss_per_batch, batch_lengths = [], []
    accuracy_per_batch = []
    for i in range(num_batches):
        training_subset=training[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size].copy()
        training_subset['q1_processed'] = training_subset['question1'].apply(lambda x: process(x, char2id, emb_matrix))
        training_subset['q2_processed'] = training_subset['question2'].apply(lambda x: process(x, char2id, emb_matrix))
        q1_data = np.array(training_subset['q1_processed'].tolist())
        q2_data = np.array(training_subset['q2_processed'].tolist())
        label_subset=np.array(list(training_subset['is_duplicate']))
        label_subset = np.reshape(label_subset, (label_subset.shape[0], 1))
        #q1_subset=train_X_q1[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        #q2_subset=train_X_q2[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        #label_subset=train_Y[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        #label_subset=np.reshape(label_subset,(label_subset.shape[0],1))
        train_data_dict={
            q1_vectors: q1_data,
            q2_vectors: q2_data,
            labels:label_subset,
            keep_prob:(1.0 - FLAGS.dropout),
            is_training:True
        }
        loss_local, _, acc = sess.run([loss, train_op, accuracy], feed_dict=train_data_dict)
        curr_batch_size = training_subset.shape[0]
        loss_per_batch.append(loss_local * curr_batch_size)
        accuracy_per_batch.append(acc * curr_batch_size)
        batch_lengths.append(curr_batch_size)
    total_num_examples = sum(batch_lengths)
    train_loss = sum(loss_per_batch) / float(total_num_examples)
    train_accuracy = sum(accuracy_per_batch) / float(total_num_examples)
    print("Total examples in training batch "+str(total_num_examples))
    print("Train Loss "+str(train_loss))
    print("Train accuracy "+str(train_accuracy))
    num_batches = int(val_X_q1.shape[0]) // FLAGS.batch_size
    if FLAGS.batch_size * num_batches < val_X_q1.shape[0]: num_batches += 1
    loss_per_batch, batch_lengths = [], []
    accuracy_per_batch = []
    for i in range(num_batches):
        q1_subset = val_X_q1[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        q2_subset = val_X_q2[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        q1_mask_subset = (q1_subset != 0).astype(np.int32)
        q2_mask_subset = (q2_subset != 0).astype(np.int32)
        label_subset = val_Y[i * FLAGS.batch_size:(i + 1) * FLAGS.batch_size]
        label_subset = np.reshape(label_subset, (label_subset.shape[0], 1))
        val_data_dict = {
            q1_ids: q1_subset,
            q2_ids: q2_subset,
            labels: label_subset,
            keep_prob: 1.0,
            is_training: False
        }
        loss_local, acc, pred = sess.run([loss, accuracy, predicted], feed_dict=val_data_dict)
        curr_batch_size = q1_subset.shape[0]
        loss_per_batch.append(loss_local * curr_batch_size)
        accuracy_per_batch.append(acc * curr_batch_size)
        batch_lengths.append(curr_batch_size)
    total_num_examples = sum(batch_lengths)
    dev_loss = sum(loss_per_batch) / float(total_num_examples)
    dev_accuracy = sum(accuracy_per_batch) / float(total_num_examples)
    print("Total examples in val batch " + str(total_num_examples))
    print("Val Loss " + str(dev_loss))
    print("Val accuracy " + str(dev_accuracy))

